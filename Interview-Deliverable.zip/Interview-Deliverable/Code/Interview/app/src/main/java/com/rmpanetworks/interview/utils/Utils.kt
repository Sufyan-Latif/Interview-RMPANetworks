package com.rmpanetworks.interview.utils

import com.google.android.gms.maps.model.LatLng

object Utils {
    var destinationLatLng: LatLng = LatLng(25.2412525, 55.2881036)
    var destinationChanged: Boolean = false
}